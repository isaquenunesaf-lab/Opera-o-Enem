(function(){
'use strict';
// Cronograma editável: altere datas, temas e tarefas aqui, sem mexer na interface.
const D=(n,date,area,lib,tema,min,items)=>({id:'d'+n,label:'Dia '+n,date,area,lib,tema,min,items});
const DAYS=[
D(1,'2026-10-27','Todas as áreas','Geral','Diagnóstico e planejamento',120,['Questões diagnósticas de todas as áreas','Identificação das principais dificuldades','Definição da rotina de estudos','Registro dos resultados iniciais']),
D(2,'2026-10-28','Linguagens','Português','Linguagens',120,['Interpretação e compreensão textual','Gêneros textuais','Funções da linguagem','Variação linguística','Figuras de linguagem','Inglês ou espanhol, conforme a sua opção']),
D(3,'2026-10-29','Ciências Humanas','História','História',120,['Brasil Colônia e escravidão','República brasileira e Era Vargas','Ditadura militar e redemocratização','Cidadania e movimentos sociais']),
D(4,'2026-10-30','Ciências Humanas','Geografia','Geografia, Filosofia e Sociologia',120,['Urbanização e população','Globalização e questões ambientais','Clima e agricultura','Cultura e desigualdade social','Ética, cidadania e pensamento político']),
D(5,'2026-10-31','Matemática','Matemática','Matemática I',120,['Porcentagem','Razão e proporção','Regra de três','Escalas','Média, mediana e interpretação de gráficos']),
D(6,'2026-11-01','Redação','Redação','Redação I',150,['Estrutura dissertativo-argumentativa','Construção da tese','Desenvolvimento de argumentos','Repertório sociocultural','Coesão e conectivos','Produção de uma redação completa']),
D(7,'2026-11-02','Ciências da Natureza','Biologia','Biologia',120,['Ecologia e relações ecológicas','Cadeias e teias alimentares','Genética básica e evolução','Fisiologia humana e saúde']),
D(8,'2026-11-03','Ciências da Natureza','Química','Química',120,['Misturas e separação de materiais','Estequiometria básica','Soluções e concentração','pH','Química ambiental','Eletroquímica básica']),
D(9,'2026-11-04','Ciências da Natureza','Física','Física',120,['Cinemática','Leis de Newton','Energia, trabalho e potência','Eletricidade e circuitos simples','Calorimetria','Consumo de energia']),
D(10,'2026-11-05','Matemática','Matemática','Matemática II',120,['Geometria plana e espacial','Áreas e volumes','Semelhança','Probabilidade básica','Funções e interpretação de gráficos']),
D(11,'2026-11-06','Linguagens e Ciências Humanas','Geral','Revisão integrada do primeiro dia',150,['Questões mistas de Linguagens','Questões mistas de Ciências Humanas','Interpretação de textos, imagens e gráficos','Revisão da estrutura da redação','Correção dos erros acumulados']),
D(12,'2026-11-07','Preparação','Geral','Revisão leve e preparação para a prova',60,['Revisão das anotações pessoais','Consulta dos documentos necessários','Conferência do cartão de confirmação','Planejamento do transporte e do horário de saída','Separação dos materiais permitidos','Orientações para descanso e alimentação'])
];
// Etapa complementar: entre o 1º e o 2º dia de prova.
const COMP={id:'c',label:'Etapa complementar',date:'2026-11-09',end:'2026-11-14',area:'Matemática e Ciências da Natureza',lib:'',tema:'Revisão de Matemática e Ciências da Natureza',min:90,
 items:['Refazer questões de Matemática que você errou','Revisar Física, Química e Biologia pelas suas anotações de dificuldades','Registrar o desempenho em Meu progresso','Conferir novamente o checklist do dia da prova']};
const CONFIG={provas:[{id:'d1',label:'1º dia do ENEM 2026',date:'2026-11-08'},{id:'d2',label:'2º dia do ENEM 2026',date:'2026-11-15'}]};
const ALL=DAYS.concat([COMP]);
const key=(d,i)=>d.id+'-'+i;
const Plan=window.Plan={CONFIG,DAYS,COMP,ALL,key,
  stats(s,list){let t=0,d=0;(list||ALL).forEach(x=>x.items.forEach((_,i)=>{t++;if(s.tasks[key(x,i)])d++;}));return{total:t,done:d};},
  nextExam:()=>CONFIG.provas.find(p=>p.date>=U.today())||null,
  isToday:d=>{const t=U.today();return d.date<=t&&t<=(d.end||d.date);},
  today:()=>ALL.find(Plan.isToday)||null,
  next:()=>ALL.find(d=>d.date>U.today())||null,
  firstPending:s=>ALL.find(d=>d.items.some((_,i)=>!s.tasks[key(d,i)]))||null,
  card(d,s){
    const st=Plan.stats(s,[d]),c=st.done===st.total?'done':st.done?'doing':'todo',lab={done:'Concluído',doing:'Em andamento',todo:'Pendente'}[c];
    return `<article class="card day ${c}" id="${d.id}"><div class="day-h"><span class="badge">${d.label}</span><span>${d.end?U.short(d.date)+' a '+U.short(d.end):U.short(d.date)}${Plan.isToday(d)?' · <strong>hoje</strong>':''}</span><span class="state ${c}">${lab}</span></div>
<h3>${d.tema}</h3><p class="muted">${d.area} · tempo estimado: cerca de ${d.min} min</p>
<ul class="tasks">${d.items.map((t,i)=>`<li><label><input type="checkbox" data-task="${key(d,i)}"${s.tasks[key(d,i)]?' checked':''}><span>${t}</span></label></li>`).join('')}</ul>
<progress max="${st.total}" value="${st.done}" aria-label="Progresso de ${d.label}"></progress><p class="muted">${st.done} de ${st.total} tarefas</p>
<label class="field">Dificuldades (opcional)<textarea data-note="${d.id}" rows="2">${U.esc(s.notes[d.id]||'')}</textarea></label>
<button class="btn ghost" data-go="biblioteca" data-lib="${d.lib}">Abrir materiais relacionados</button></article>`;}
};
const V=window.Views=window.Views||{};
let flt='todos';
V.plano={
  render(){
    const s=Store.get(),t=U.today();
    const fs={todos:()=>1,ant:d=>(d.end||d.date)<t,hoje:Plan.isToday,prox:d=>d.date>t};
    const list=ALL.filter(fs[flt]);
    return `<h1>Plano de estudos</h1><p class="muted">Cronograma-base editável, sem lista oficial de incidência do ENEM e sem garantia de nota. Marque e desmarque tarefas livremente: nenhum dia é bloqueado se você atrasar.</p>
<div class="row" role="group" aria-label="Filtrar dias">${[['todos','Todos'],['ant','Anteriores'],['hoje','Hoje'],['prox','Próximos']].map(([k,l])=>`<button class="btn ghost sm" data-flt="${k}" aria-pressed="${flt===k}">${l}</button>`).join('')}</div>
${list.length?list.map(d=>Plan.card(d,s)).join(''):'<p class="card">Nenhum dia neste filtro. Tente outra opção.</p>'}
<p class="muted">Etapa complementar: após o 1º dia de prova, revise Matemática e Ciências da Natureza até o 2º dia (datas configuráveis em js/cronograma.js).</p>`;
  },
  bind(a){a.querySelectorAll('[data-flt]').forEach(b=>b.onclick=()=>{flt=b.dataset.flt;App.render();});}
};
})();
